# Quetta + Soul Browser Clone (v2.0) — Inbuilt AdBlocker + Media/PDF Downloader + Chrome Extensions

Yeh updated v2 Android project **Quetta Browser** ke exact Bottom UI, **Inbuilt Network AdBlocker**, **Desktop Chrome Extensions (`.crx`/`.zip`)**, aur **Soul Browser** jaise **Smart Video, Audio & PDF Sniffer/Downloader** ke saath aata hai.

---

## 🔥 Naye v2 Features

1. **🛡️ Quetta Inbuilt Network + Cosmetic AdBlocker (`QuettaAdBlocker.kt`):**
   - `WebViewClient.shouldInterceptRequest` ke zariye network level par hi Ad aur Tracker domains (`doubleclick`, `googlesyndication`, `taboola`, `popads`, etc.) ko block kar deta hai.
   - Bottom Address Bar mein live **`🛡️0`** counter dikhta hai ki kitne ads block huye.
   - Pop-up blocker aur Cookie Banner hider bhi inbuilt hai.

2. **⬇️ Soul Browser Style Video, Audio & PDF Forced Downloader (`SoulMediaDownloader.kt`):**
   - **Live Media & PDF Sniffer:** Page load hote hi network streams aur HTML5 `<video>`, `<audio>`, `<source>`, `<embed>`, aur `<a href>` tags ko scan karke saare direct `.mp4`, `.webm`, `.mp3`, `.m4a`, `.wav`, aur `.pdf` links pakad leta hai.
   - **Unlocks `nodownload` Controls:** Jin websites par `<video controlsList="nodownload">` laga hota hai, usey automatically unlock kar deta hai.
   - **Session Cookie + Referer Forwarding:** Android `DownloadManager` mein active browser `Cookie`, `Referer`, aur `User-Agent` headers bhejta hai taaki login-protected PDFs ya media files fail na hon.
   - **Long-Press Force Download & Webpage-to-PDF:** Kisi bhi link ya media par long-press karke seedha download kar sakte hain, ya kisi bhi webpage ko `Force Save Current Page as PDF` se PDF bana sakte hain.

---

## 🚀 GitHub Actions se 3 Minute mein `.APK` Kaise Banayein
1. Is ZIP file ko extract karke apne GitHub repository mein upload karein.
2. GitHub ke **Actions** tab mein jayein — `Build Quetta Clone APK` workflow automatically run hoga.
3. **Artifacts** section se **`Quetta-Soul-Browser-APK`** download karke apne Android phone mein install kar lein!
