package com.quetta.clone.downloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.widget.Toast

enum class ResourceCategory {
    VIDEO, AUDIO, PDF, DOCUMENT
}

data class SniffedResource(
    val url: String,
    val fileName: String,
    val category: ResourceCategory,
    val mimeType: String,
    val sourcePageUrl: String
)

class SoulMediaDownloader(private val context: Context) {

    // Stores unique resources detected on the active page (like Soul Browser's resource sniffer)
    val detectedResources = linkedMapOf<String, SniffedResource>()

    // Automatically force-download PDF links when clicked instead of failing in WebView
    var autoForceDownloadPdf: Boolean = true

    private val videoExtensions = listOf(".mp4", ".webm", ".mkv", ".mov", ".m4v", ".3gp", ".avi")
    private val audioExtensions = listOf(".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac", ".opus")
    private val pdfExtensions = listOf(".pdf")
    private val docExtensions = listOf(".epub", ".zip", ".rar", ".7z", ".apk", ".docx", ".xlsx", ".pptx")

    fun clearForNewPage() {
        detectedResources.clear()
    }

    /**
     * Inspects network requests and DOM URLs to sniff downloadable Video, Audio, and PDF files
     * (Strictly ignores blob: and encrypted DRM streams).
     */
    fun inspectUrl(url: String, pageUrl: String = ""): SniffedResource? {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return null
        val cleanPath = url.substringBefore("?").substringBefore("#").lowercase()

        val category = when {
            videoExtensions.any { cleanPath.endsWith(it) } || url.lowercase().contains("mime=video") -> ResourceCategory.VIDEO
            audioExtensions.any { cleanPath.endsWith(it) } || url.lowercase().contains("mime=audio") -> ResourceCategory.AUDIO
            pdfExtensions.any { cleanPath.endsWith(it) } || url.lowercase().contains("content-type=application/pdf") -> ResourceCategory.PDF
            docExtensions.any { cleanPath.endsWith(it) } -> ResourceCategory.DOCUMENT
            else -> return null
        }

        val mime = when (category) {
            ResourceCategory.VIDEO -> "video/mp4"
            ResourceCategory.AUDIO -> "audio/mpeg"
            ResourceCategory.PDF -> "application/pdf"
            ResourceCategory.DOCUMENT -> "application/octet-stream"
        }

        val guessedName = URLUtil.guessFileName(url, null, mime)
        val resource = SniffedResource(
            url = url,
            fileName = guessedName,
            category = category,
            mimeType = mime,
            sourcePageUrl = pageUrl
        )
        detectedResources[url] = resource
        return resource
    }

    /**
     * Registers a resource directly reported by the DOM scanner JS bridge
     */
    fun registerDomResource(url: String, typeHint: String, pageUrl: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        if (detectedResources.containsKey(url)) return

        val category = when (typeHint.uppercase()) {
            "VIDEO" -> ResourceCategory.VIDEO
            "AUDIO" -> ResourceCategory.AUDIO
            "PDF" -> ResourceCategory.PDF
            else -> inspectUrl(url, pageUrl)?.category ?: return
        }

        val mime = when (category) {
            ResourceCategory.VIDEO -> "video/mp4"
            ResourceCategory.AUDIO -> "audio/mpeg"
            ResourceCategory.PDF -> "application/pdf"
            ResourceCategory.DOCUMENT -> "application/octet-stream"
        }

        val fileName = URLUtil.guessFileName(url, null, mime)
        detectedResources[url] = SniffedResource(
            url = url,
            fileName = fileName,
            category = category,
            mimeType = mime,
            sourcePageUrl = pageUrl
        )
    }

    /**
     * JavaScript injected on every page to:
     * 1. Unlock <video controlsList="nodownload"> and <audio controlsList="nodownload">
     * 2. Scan <video>, <audio>, <source>, <embed>, <object>, <iframe>, and <a href> for direct Video, Audio, and PDF links
     * 3. Report them to SoulBridge so the user can download them with one tap.
     */
    fun getDomSnifferScript(): String {
        return """
        (function() {
            function scanMediaAndPdfs() {
                // 1. Unlock HTML5 Video & Audio tags and sniff direct HTTP sources
                document.querySelectorAll('video, audio').forEach(media => {
                    if (media.hasAttribute('controlsList')) {
                        media.removeAttribute('controlsList');
                    }
                    media.controls = true;
                    const tagType = media.tagName.toUpperCase();
                    const src = media.currentSrc || media.src;
                    if (src && src.startsWith('http') && window.QuettaNativeBridge) {
                        window.QuettaNativeBridge.onMediaSniffed(src, tagType, location.href);
                    }
                    media.querySelectorAll('source').forEach(s => {
                        if (s.src && s.src.startsWith('http') && window.QuettaNativeBridge) {
                            window.QuettaNativeBridge.onMediaSniffed(s.src, tagType, location.href);
                        }
                    });
                });

                // 2. Scan <a href>, <embed>, <object>, <iframe> for PDF, Audio, and Video links
                document.querySelectorAll('a[href], embed[src], object[data], iframe[src]').forEach(el => {
                    const rawUrl = el.href || el.src || el.data || '';
                    if (!rawUrl || !rawUrl.startsWith('http')) return;
                    const lower = rawUrl.split('?')[0].toLowerCase();
                    if (lower.endsWith('.pdf') || el.type === 'application/pdf') {
                        if (window.QuettaNativeBridge) {
                            window.QuettaNativeBridge.onMediaSniffed(rawUrl, 'PDF', location.href);
                        }
                    } else if (lower.endsWith('.mp4') || lower.endsWith('.webm') || lower.endsWith('.mkv')) {
                        if (window.QuettaNativeBridge) {
                            window.QuettaNativeBridge.onMediaSniffed(rawUrl, 'VIDEO', location.href);
                        }
                    } else if (lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.wav') || lower.endsWith('.ogg')) {
                        if (window.QuettaNativeBridge) {
                            window.QuettaNativeBridge.onMediaSniffed(rawUrl, 'AUDIO', location.href);
                        }
                    }
                });
            }

            scanMediaAndPdfs();
            setTimeout(scanMediaAndPdfs, 2500);
        })();
        """.trimIndent()
    }

    /**
     * Soul Browser Style Forced Downloader using Android DownloadManager with Session Cookies,
     * Referer, and User-Agent headers so protected/authenticated direct files download smoothly.
     */
    fun forceDownloadUrl(
        url: String,
        userAgent: String? = null,
        contentDisposition: String? = null,
        mimeType: String? = null,
        refererUrl: String? = null,
        customFileName: String? = null
    ) {
        try {
            val uri = Uri.parse(url)
            val resolvedMime = mimeType ?: when {
                url.lowercase().contains(".pdf") -> "application/pdf"
                url.lowercase().contains(".mp3") || url.lowercase().contains(".m4a") -> "audio/mpeg"
                url.lowercase().contains(".mp4") || url.lowercase().contains(".webm") -> "video/mp4"
                else -> "*/*"
            }

            val fileName = customFileName
                ?: URLUtil.guessFileName(url, contentDisposition, resolvedMime)

            val request = DownloadManager.Request(uri).apply {
                setTitle(fileName)
                setDescription("Soul Downloader • ${uri.host ?: "File"}")
                setMimeType(resolvedMime)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)

                // Forward browser session cookies & headers so servers don't reject the download
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrEmpty()) {
                    addRequestHeader("Cookie", cookies)
                }
                if (!userAgent.isNullOrEmpty()) {
                    addRequestHeader("User-Agent", userAgent)
                }
                if (!refererUrl.isNullOrEmpty()) {
                    addRequestHeader("Referer", refererUrl)
                }

                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)

            Toast.makeText(
                context,
                "⬇️ Downloading: $fileName (Saved to Downloads)",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "⚠️ Download error: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /**
     * Exports any rendered webpage or inline document as a PDF file using Android's PrintManager
     */
    fun exportCurrentWebPageAsPdf(webView: WebView) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager != null) {
            val jobName = "Quetta_${webView.title ?: "Document"}_PDF"
            val printAdapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
        } else {
            Toast.makeText(context, "Print/PDF service unavailable", Toast.LENGTH_SHORT).show()
        }
    }
}
