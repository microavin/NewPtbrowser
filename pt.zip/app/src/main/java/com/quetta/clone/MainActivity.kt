package com.quetta.clone

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.quetta.clone.adblock.QuettaAdBlocker
import com.quetta.clone.databinding.ActivityMainBinding
import com.quetta.clone.downloader.ResourceCategory
import com.quetta.clone.downloader.SoulMediaDownloader
import com.quetta.clone.extension.ChromeApiPolyfill
import com.quetta.clone.extension.CrxExtensionManager

data class BrowserTab(
    val id: Long,
    var title: String = "New Tab",
    var url: String = "https://www.google.com",
    val webView: WebView
)

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var extensionManager: CrxExtensionManager
    private lateinit var adBlocker: QuettaAdBlocker
    private lateinit var soulDownloader: SoulMediaDownloader

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabIndex = 0
    private var isDesktopMode = false

    private val crxFilePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                installExtensionFromUri(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        extensionManager = CrxExtensionManager(this)
        adBlocker = QuettaAdBlocker()
        soulDownloader = SoulMediaDownloader(this)

        setupBottomBarListeners()

        val startUrl = intent?.dataString ?: "https://www.google.com"
        createNewTab(startUrl)
    }

    private fun setupBottomBarListeners() {
        binding.btnBack.setOnClickListener {
            currentWebView()?.let { if (it.canGoBack()) it.goBack() }
        }

        binding.btnReload.setOnClickListener {
            currentWebView()?.reload()
        }

        binding.etOmnibox.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                loadUserInput(v.text.toString())
                true
            } else false
        }

        // Quetta Built-in AdBlocker Shield Control Panel
        binding.tvShieldBadge.setOnClickListener {
            showQuettaAdBlockBottomSheet()
        }

        // Soul Browser Style Media / Audio / PDF Sniffer & Forced Downloader Sheet
        binding.btnDownloader.setOnClickListener {
            showSoulDownloaderBottomSheet()
        }

        binding.btnExtensions.setOnClickListener {
            showQuettaExtensionsBottomSheet()
        }

        binding.btnTabs.setOnClickListener {
            showQuettaTabsBottomSheet()
        }

        binding.btnMenu.setOnClickListener {
            showQuettaMainGridMenu()
        }
    }

    private fun updateBadgesOnUiThread() {
        runOnUiThread {
            binding.tvShieldBadge.text = if (adBlocker.isAdBlockEnabled) {
                "🛡️${adBlocker.totalBlockedCount}"
            } else {
                "🛡️OFF"
            }
            binding.btnDownloader.text = "⬇️${soulDownloader.detectedResources.size}"
        }
    }

    private fun loadUserInput(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return
        val finalUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${Uri.encode(trimmed)}"
        }
        currentWebView()?.loadUrl(finalUrl)
        binding.etOmnibox.clearFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createNewTab(initialUrl: String) {
        val webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.allowFileAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportMultipleWindows(!adBlocker.isPopupBlockerEnabled)
            settings.javaScriptCanOpenWindowsAutomatically = !adBlocker.isPopupBlockerEnabled
            applyUserAgent(this)

            // Native Bridge for Chrome Extensions + Soul Media/PDF DOM Sniffer
            addJavascriptInterface(object {
                @JavascriptInterface
                fun onRuntimeMessage(extId: String, payload: String): String {
                    return "{\"status\":\"ok\", \"extension\":\"$extId\"}"
                }

                @JavascriptInterface
                fun onMediaSniffed(mediaUrl: String, typeHint: String, pageUrl: String) {
                    soulDownloader.registerDomResource(mediaUrl, typeHint, pageUrl)
                    updateBadgesOnUiThread()
                }
            }, "QuettaNativeBridge")

            // 1. Force Download Listener (Handles direct files, PDFs, Audio, Video, Archives)
            setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                soulDownloader.forceDownloadUrl(
                    url = url,
                    userAgent = userAgent,
                    contentDisposition = contentDisposition,
                    mimeType = mimetype,
                    refererUrl = this.url
                )
            }

            // 2. Long-Press Any Link / Image / Video / PDF to Force Download (Soul Browser Style)
            setOnLongClickListener {
                val hitResult = this.hitTestResult
                val targetUrl = hitResult.extra
                if (!targetUrl.isNullOrEmpty() && (targetUrl.startsWith("http://") || targetUrl.startsWith("https://"))) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("⬇️ Force Download Link / Media")
                        .setMessage(targetUrl)
                        .setPositiveButton("Download File Now") { _, _ ->
                            soulDownloader.forceDownloadUrl(
                                url = targetUrl,
                                userAgent = settings.userAgentString,
                                refererUrl = this.url
                            )
                        }
                        .setNeutralButton("Open in New Tab") { _, _ ->
                            createNewTab(targetUrl)
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                } else {
                    false
                }
            }

            webViewClient = object : WebViewClient() {

                // Intercept PDF links before WebView swallows them & enforce Popup Blocker
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val reqUrl = request?.url?.toString() ?: return false
                    val clean = reqUrl.substringBefore("?").lowercase()

                    if (soulDownloader.autoForceDownloadPdf &&
                        (clean.endsWith(".pdf") || clean.endsWith(".mp3") || clean.endsWith(".mp4"))
                    ) {
                        soulDownloader.forceDownloadUrl(
                            url = reqUrl,
                            userAgent = view?.settings?.userAgentString,
                            refererUrl = view?.url
                        )
                        return true
                    }
                    return false
                }

                // Engine-Level Network AdBlocker + Soul Browser Network Media/PDF Sniffer
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val reqUrl = request?.url?.toString() ?: return null

                    // Step A: Block Ad & Tracker domains at network level
                    if (adBlocker.shouldBlockRequest(reqUrl)) {
                        updateBadgesOnUiThread()
                        return adBlocker.createEmptyResource()
                    }

                    // Step B: Sniff Video, Audio, and PDF streams passing through network
                    if (soulDownloader.inspectUrl(reqUrl) != null) {
                        updateBadgesOnUiThread()
                    }

                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    soulDownloader.clearForNewPage()
                    updateBadgesOnUiThread()
                    url?.let { binding.etOmnibox.setText(it) }
                    binding.progressBar.visibility = View.VISIBLE
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.progressBar.visibility = View.GONE
                    url?.let {
                        binding.etOmnibox.setText(it)
                        tabs.getOrNull(activeTabIndex)?.url = it
                    }
                    tabs.getOrNull(activeTabIndex)?.title = view?.title ?: "Tab"
                    if (view != null) {
                        // Inject Quetta Cosmetic AdBlocker
                        val adblockCss = adBlocker.getCosmeticFilterScript()
                        if (adblockCss.isNotEmpty()) {
                            view.evaluateJavascript(adblockCss, null)
                        }
                        // Inject Soul Browser DOM Video/Audio/PDF Sniffer
                        view.evaluateJavascript(soulDownloader.getDomSnifferScript(), null)
                        // Inject Active Chrome Extensions
                        injectActiveChromeExtensions(view)
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    binding.progressBar.progress = newProgress
                }
            }
        }

        val newTab = BrowserTab(
            id = System.currentTimeMillis(),
            url = initialUrl,
            webView = webView
        )
        tabs.add(newTab)
        switchToTab(tabs.lastIndex)
        webView.loadUrl(initialUrl)
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        activeTabIndex = index
        binding.webViewContainer.removeAllViews()
        val activeTab = tabs[activeTabIndex]
        binding.webViewContainer.addView(activeTab.webView)
        binding.etOmnibox.setText(activeTab.url)
        binding.btnTabs.text = tabs.size.toString()
    }

    private fun currentWebView(): WebView? = tabs.getOrNull(activeTabIndex)?.webView

    private fun injectActiveChromeExtensions(webView: WebView) {
        extensionManager.installedExtensions.filter { it.enabled }.forEach { ext ->
            val polyfill = ChromeApiPolyfill.getPolyfillScript(ext.id)
            webView.evaluateJavascript(polyfill, null)
            ext.jsScripts.forEach { script ->
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private fun applyUserAgent(webView: WebView) {
        webView.settings.userAgentString = if (isDesktopMode) {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        } else {
            null
        }
        webView.settings.useWideViewPort = isDesktopMode
        webView.settings.loadWithOverviewMode = isDesktopMode
    }

    /**
     * Quetta Inbuilt AdBlocker Shield Bottom Sheet
     */
    private fun showQuettaAdBlockBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 64)
            setBackgroundColor(getColor(R.color.quetta_surface))
        }

        val title = TextView(this).apply {
            text = "🛡️ Quetta Inbuilt AdBlock & Privacy Shield"
            textSize = 18f
            setTextColor(getColor(R.color.quetta_text_primary))
            setPadding(0, 0, 0, 12)
        }
        val statsTv = TextView(this).apply {
            text = "Total Ads & Trackers Blocked: ${adBlocker.totalBlockedCount}"
            textSize = 14f
            setTextColor(getColor(R.color.quetta_shield_green))
            setPadding(0, 0, 0, 28)
        }
        container.addView(title)
        container.addView(statsTv)

        val swAdBlock = Switch(this).apply {
            text = "Network + Cosmetic AdBlocker"
            setTextColor(getColor(R.color.quetta_text_primary))
            isChecked = adBlocker.isAdBlockEnabled
            setOnCheckedChangeListener { _, isChecked ->
                adBlocker.isAdBlockEnabled = isChecked
                updateBadgesOnUiThread()
                currentWebView()?.reload()
            }
        }
        val swPopup = Switch(this).apply {
            text = "Strict Pop-up & Redirect Blocker"
            setTextColor(getColor(R.color.quetta_text_primary))
            isChecked = adBlocker.isPopupBlockerEnabled
            setOnCheckedChangeListener { _, isChecked ->
                adBlocker.isPopupBlockerEnabled = isChecked
                currentWebView()?.settings?.javaScriptCanOpenWindowsAutomatically = !isChecked
            }
        }
        val swCookie = Switch(this).apply {
            text = "Hide Annoying Cookie Banners"
            setTextColor(getColor(R.color.quetta_text_primary))
            isChecked = adBlocker.isCookieBannerBlockerEnabled
            setOnCheckedChangeListener { _, isChecked ->
                adBlocker.isCookieBannerBlockerEnabled = isChecked
                currentWebView()?.reload()
            }
        }

        container.addView(swAdBlock)
        container.addView(swPopup)
        container.addView(swCookie)
        dialog.setContentView(container)
        dialog.show()
    }

    /**
     * Soul Browser Style Video, Audio & PDF Sniffer + Forced Downloader Bottom Sheet
     */
    private fun showSoulDownloaderBottomSheet() {
        // Trigger a fresh DOM scan right before opening
        currentWebView()?.evaluateJavascript(soulDownloader.getDomSnifferScript(), null)

        val dialog = BottomSheetDialog(this)
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 64)
            setBackgroundColor(getColor(R.color.quetta_surface))
        }
        scroll.addView(container)

        val title = TextView(this).apply {
            text = "⬇️ Soul Media & PDF Downloader (${soulDownloader.detectedResources.size} found)"
            textSize = 18f
            setTextColor(getColor(R.color.quetta_text_primary))
            setPadding(0, 0, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Tap any detected Video (🎬), Audio (🎵), or PDF (📄) below to forcibly download it with session cookies."
            textSize = 12f
            setTextColor(getColor(R.color.quetta_text_secondary))
            setPadding(0, 0, 0, 24)
        }
        container.addView(title)
        container.addView(subtitle)

        val resourcesList = soulDownloader.detectedResources.values.toList()
        if (resourcesList.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No direct Video/Audio/PDF streams detected yet on this page. Play a video/audio or use the buttons below to force-download any URL or export this page as PDF."
                textSize = 13f
                setTextColor(getColor(R.color.quetta_text_secondary))
                setPadding(0, 16, 0, 24)
            }
            container.addView(emptyTv)
        } else {
            resourcesList.forEach { res ->
                val badge = when (res.category) {
                    ResourceCategory.VIDEO -> "🎬 [VIDEO]"
                    ResourceCategory.AUDIO -> "🎵 [AUDIO]"
                    ResourceCategory.PDF -> "📄 [PDF]"
                    ResourceCategory.DOCUMENT -> "📦 [FILE]"
                }
                val itemBtn = Button(this).apply {
                    text = "$badge ${res.fileName}\n${res.url.take(60)}..."
                    isAllCaps = false
                    setOnClickListener {
                        dialog.dismiss()
                        soulDownloader.forceDownloadUrl(
                            url = res.url,
                            userAgent = currentWebView()?.settings?.userAgentString,
                            mimeType = res.mimeType,
                            refererUrl = currentWebView()?.url,
                            customFileName = res.fileName
                        )
                    }
                }
                container.addView(itemBtn)
            }
        }

        // Action 1: Force Download Custom URL (Video / Audio / PDF)
        val btnForceCustomUrl = Button(this).apply {
            text = "🔗 Force Download Any Direct URL (Video / Audio / PDF)"
            isAllCaps = false
            setOnClickListener {
                dialog.dismiss()
                showForceCustomUrlDialog()
            }
        }

        // Action 2: Force Save Current Webpage / Inline Document as PDF
        val btnExportPdf = Button(this).apply {
            text = "📄 Force Save Current Page as PDF"
            isAllCaps = false
            setOnClickListener {
                dialog.dismiss()
                currentWebView()?.let { soulDownloader.exportCurrentWebPageAsPdf(it) }
            }
        }

        // Action 3: Open System Downloads Folder
        val btnOpenDownloads = Button(this).apply {
            text = "📂 Open System Downloads Manager"
            isAllCaps = false
            setOnClickListener {
                dialog.dismiss()
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            }
        }

        container.addView(btnForceCustomUrl)
        container.addView(btnExportPdf)
        container.addView(btnOpenDownloads)

        dialog.setContentView(scroll)
        dialog.show()
    }

    private fun showForceCustomUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/file.pdf or .mp4 / .mp3"
            setText(currentWebView()?.url ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("Force Download URL")
            .setMessage("Paste any direct Video, Audio, or PDF link to download with active cookies:")
            .setView(input)
            .setPositiveButton("Download Now") { _, _ ->
                val targetUrl = input.text.toString().trim()
                if (targetUrl.isNotEmpty()) {
                    soulDownloader.forceDownloadUrl(
                        url = targetUrl,
                        userAgent = currentWebView()?.settings?.userAgentString,
                        refererUrl = currentWebView()?.url
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Quetta-Style Extensions Bottom Sheet
     */
    private fun showQuettaExtensionsBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 64)
            setBackgroundColor(getColor(R.color.quetta_surface))
        }

        val title = TextView(this).apply {
            text = "🧩 Extensions (Quetta WebExtensions)"
            textSize = 18f
            setTextColor(getColor(R.color.quetta_text_primary))
            setPadding(0, 0, 0, 24)
        }
        container.addView(title)

        extensionManager.installedExtensions.forEach { ext ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 20, 0, 20)
            }
            val infoLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val nameTv = TextView(this).apply {
                text = "${ext.name} (v${ext.version})"
                textSize = 15f
                setTextColor(getColor(R.color.quetta_text_primary))
            }
            val descTv = TextView(this).apply {
                text = ext.description
                textSize = 12f
                setTextColor(getColor(R.color.quetta_text_secondary))
            }
            infoLayout.addView(nameTv)
            infoLayout.addView(descTv)

            val toggle = Switch(this).apply {
                isChecked = ext.enabled
                setOnCheckedChangeListener { _, isChecked ->
                    ext.enabled = isChecked
                    currentWebView()?.reload()
                }
            }

            row.addView(infoLayout)
            row.addView(toggle)
            container.addView(row)
        }

        val btnInstallCrx = Button(this).apply {
            text = "📦 Install .CRX / .ZIP Extension File"
            setOnClickListener {
                dialog.dismiss()
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                crxFilePicker.launch(Intent.createChooser(intent, "Select Chrome .crx or .zip Extension"))
            }
        }
        val btnWebStore = Button(this).apply {
            text = "🌐 Open Chrome Web Store"
            setOnClickListener {
                dialog.dismiss()
                currentWebView()?.loadUrl("https://chromewebstore.google.com")
            }
        }

        container.addView(btnInstallCrx)
        container.addView(btnWebStore)
        dialog.setContentView(container)
        dialog.show()
    }

    private fun installExtensionFromUri(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { stream ->
                val ext = extensionManager.installFromCrxOrZip(
                    stream,
                    uri.lastPathSegment ?: "custom_ext"
                )
                if (ext != null) {
                    Toast.makeText(
                        this,
                        "✅ Installed Extension: ${ext.name}",
                        Toast.LENGTH_LONG
                    ).show()
                    currentWebView()?.reload()
                } else {
                    Toast.makeText(
                        this,
                        "⚠️ Invalid extension archive (manifest.json not found)",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error installing CRX: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showQuettaTabsBottomSheet() {
        val tabTitles = tabs.mapIndexed { idx, tab ->
            val prefix = if (idx == activeTabIndex) "🟢 " else "⚪ "
            "$prefix${tab.title} (${tab.url.take(35)})"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(tabTitles) { _, which ->
                switchToTab(which)
            }
            .setPositiveButton("➕ New Tab") { _, _ ->
                createNewTab("https://www.google.com")
            }
            .setNeutralButton("Close Current Tab") { _, _ ->
                if (tabs.size > 1) {
                    tabs.removeAt(activeTabIndex)
                    switchToTab(0)
                }
            }
            .show()
    }

    private fun showQuettaMainGridMenu() {
        val actions = arrayOf(
            "⬇️ Soul Media & PDF Downloader (${soulDownloader.detectedResources.size})",
            "🛡️ Quetta AdBlock Shield (${adBlocker.totalBlockedCount} blocked)",
            "🧩 Chrome Extensions Manager",
            "📄 Force Save Current Page as PDF",
            if (isDesktopMode) "📱 Switch to Mobile Site" else "🖥️ Desktop Site Mode",
            "🧹 Clear Browsing Data & Cache",
            "➕ New Private Tab"
        )
        AlertDialog.Builder(this)
            .setTitle("Quetta + Soul Menu")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showSoulDownloaderBottomSheet()
                    1 -> showQuettaAdBlockBottomSheet()
                    2 -> showQuettaExtensionsBottomSheet()
                    3 -> currentWebView()?.let { soulDownloader.exportCurrentWebPageAsPdf(it) }
                    4 -> {
                        isDesktopMode = !isDesktopMode
                        currentWebView()?.let {
                            applyUserAgent(it)
                            it.reload()
                        }
                    }
                    5 -> {
                        currentWebView()?.clearCache(true)
                        CookieManager.getInstance().removeAllCookies(null)
                        Toast.makeText(this, "🧹 Browsing data cleared!", Toast.LENGTH_SHORT).show()
                    }
                    6 -> createNewTab("https://duckduckgo.com")
                }
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val wv = currentWebView()
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
