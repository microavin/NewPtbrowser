package com.quetta.clone.adblock

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

class QuettaAdBlocker {

    var isAdBlockEnabled: Boolean = true
    var isPopupBlockerEnabled: Boolean = true
    var isCookieBannerBlockerEnabled: Boolean = true
    var totalBlockedCount: Int = 0
        private set

    // Built-in high-efficiency network blocklist (Ad & Tracker hosts)
    private val blockedHostKeywords = listOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.",
        "pagead2.googlesyndication.com",
        "adnxs.com",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "criteo.net",
        "scorecardresearch.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "adsterra.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "mgid.com",
        "revcontent.com",
        "zedo.com",
        "advertising.com",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "moatads.com",
        "amazon-adsystem.com",
        "hotjar.com",
        "clarity.ms"
    )

    private val blockedPathPatterns = listOf(
        "/ads/", "/adserver/", "/adframe.", "/popunder", "/banner_ads/", "/pagead/"
    )

    fun shouldBlockRequest(url: String): Boolean {
        if (!isAdBlockEnabled) return false
        val lowerUrl = url.lowercase()
        val host = Uri.parse(lowerUrl).host ?: return false

        val hostMatched = blockedHostKeywords.any { host.contains(it) }
        val pathMatched = blockedPathPatterns.any { lowerUrl.contains(it) }

        if (hostMatched || pathMatched) {
            totalBlockedCount++
            return true
        }
        return false
    }

    fun createEmptyResource(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            ByteArrayInputStream(ByteArray(0))
        )
    }

    /**
     * Quetta Cosmetic Element Hider + Anti-Overlay + Cookie Notice Hider
     */
    fun getCosmeticFilterScript(): String {
        if (!isAdBlockEnabled) return ""
        val cookieSelectors = if (isCookieBannerBlockerEnabled) {
            ", [id*='cookie-banner'], [class*='cookie-consent'], [id*='onetrust-consent'], .cc-window"
        } else ""

        return """
        (function() {
            if (document.getElementById('__quetta_native_adblock')) return;
            const style = document.createElement('style');
            style.id = '__quetta_native_adblock';
            style.innerHTML = `
                ins.adsbygoogle, [id^="div-gpt-ad"], [id*="google_ads_iframe"],
                [class*="ad-container"], [class*="ad-wrapper"], [class*="sponsored-post"],
                iframe[src*="doubleclick"], iframe[src*="googlesyndication"],
                .ad-banner, .adsbox, .ad-slot $cookieSelectors {
                    display: none !important;
                    height: 0 !important;
                    visibility: hidden !important;
                    pointer-events: none !important;
                }
            `;
            document.documentElement.appendChild(style);
        })();
        """.trimIndent()
    }
}
