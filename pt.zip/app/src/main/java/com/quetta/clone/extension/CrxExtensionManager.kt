package com.quetta.clone.extension

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

data class InstalledExtension(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    var enabled: Boolean = true,
    val jsScripts: List<String> = emptyList(),
    val cssStyles: List<String> = emptyList(),
    val popupHtmlPath: String? = null
)

class CrxExtensionManager(private val context: Context) {

    private val extensionsDir = File(context.filesDir, "extensions").apply { mkdirs() }
    val installedExtensions = mutableListOf<InstalledExtension>()

    init {
        loadBuiltInExtensions()
        loadUserInstalledExtensions()
    }

    private fun loadBuiltInExtensions() {
        installedExtensions.add(
            InstalledExtension(
                id = "quetta-dark-reader",
                name = "Dark Reader Pro (WebExtension)",
                version = "4.9.80",
                description = "Applies smart dark theme to every website automatically.",
                enabled = false,
                jsScripts = listOf(
                    """
                    (function() {
                        if (document.getElementById('__quetta_dark_reader')) return;
                        const style = document.createElement('style');
                        style.id = '__quetta_dark_reader';
                        style.innerHTML = 'html { filter: invert(90%) hue-rotate(180deg) !important; background: #111 !important; } img, video, iframe, canvas { filter: invert(100%) hue-rotate(180deg) !important; }';
                        document.documentElement.appendChild(style);
                    })();
                    """.trimIndent()
                )
            )
        )

        installedExtensions.add(
            InstalledExtension(
                id = "quetta-yt-skipper",
                name = "Video Ad & Sponsor Auto-Skipper",
                version = "2.1.0",
                description = "Automatically clicks Skip Ad buttons on video players.",
                enabled = true,
                jsScripts = listOf(
                    """
                    (function() {
                        setInterval(() => {
                            const skipBtn = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
                            if (skipBtn) skipBtn.click();
                        }, 800);
                    })();
                    """.trimIndent()
                )
            )
        )
    }

    fun installFromCrxOrZip(inputStream: InputStream, fallbackId: String): InstalledExtension? {
        val rawBytes = inputStream.readBytes()
        val zipBytes = stripCrxHeaderIfNeeded(rawBytes)
        val extId = "crx_" + fallbackId.replace("[^a-zA-Z0-9_]".toRegex(), "_")
        val targetDir = File(extensionsDir, extId).apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath)) {
                    throw SecurityException("Zip Slip prevented")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        return parseUnpackedExtension(targetDir)?.also { ext ->
            installedExtensions.removeAll { it.id == ext.id }
            installedExtensions.add(ext)
        }
    }

    private fun stripCrxHeaderIfNeeded(bytes: ByteArray): ByteArray {
        if (bytes.size > 16 &&
            bytes[0] == 'C'.code.toByte() &&
            bytes[1] == 'r'.code.toByte() &&
            bytes[2] == '2'.code.toByte() &&
            bytes[3] == '4'.code.toByte()
        ) {
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            buffer.position(4)
            val version = buffer.int
            if (version == 3) {
                val headerSize = buffer.int
                val zipStartOffset = 12 + headerSize
                if (zipStartOffset in 1 until bytes.size) {
                    return bytes.copyOfRange(zipStartOffset, bytes.size)
                }
            } else if (version == 2) {
                val pubKeyLen = buffer.int
                val sigLen = buffer.int
                val zipStartOffset = 16 + pubKeyLen + sigLen
                if (zipStartOffset in 1 until bytes.size) {
                    return bytes.copyOfRange(zipStartOffset, bytes.size)
                }
            }
        }
        return bytes
    }

    private fun loadUserInstalledExtensions() {
        extensionsDir.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
            parseUnpackedExtension(dir)?.let { installedExtensions.add(it) }
        }
    }

    private fun parseUnpackedExtension(dir: File): InstalledExtension? {
        val manifestFile = File(dir, "manifest.json")
        if (!manifestFile.exists()) return null
        return try {
            val json = JSONObject(manifestFile.readText())
            val name = json.optString("name", dir.name)
            val version = json.optString("version", "1.0")
            val desc = json.optString("description", "Custom Chrome WebExtension")

            val jsCodeList = mutableListOf<String>()
            val contentScripts = json.optJSONArray("content_scripts")
            if (contentScripts != null) {
                for (i in 0 until contentScripts.length()) {
                    val cs = contentScripts.getJSONObject(i)
                    val jsFiles = cs.optJSONArray("js")
                    if (jsFiles != null) {
                        for (j in 0 until jsFiles.length()) {
                            val scriptFile = File(dir, jsFiles.getString(j))
                            if (scriptFile.exists()) {
                                jsCodeList.add(scriptFile.readText())
                            }
                        }
                    }
                }
            }

            val actionObj = json.optJSONObject("action") ?: json.optJSONObject("browser_action")
            val popupRelPath = actionObj?.optString("default_popup")?.takeIf { it.isNotEmpty() }
            val popupFullPath = popupRelPath?.let { File(dir, it).absolutePath }

            InstalledExtension(
                id = dir.name,
                name = name,
                version = version,
                description = desc,
                enabled = true,
                jsScripts = jsCodeList,
                popupHtmlPath = popupFullPath
            )
        } catch (e: Exception) {
            null
        }
    }
}
