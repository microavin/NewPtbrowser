package com.quetta.clone.extension

object ChromeApiPolyfill {
    fun getPolyfillScript(extensionId: String): String {
        return """
        (function() {
            if (window.chrome && window.chrome.__quettaPolyfillLoaded) return;
            window.chrome = window.chrome || {};
            window.chrome.__quettaPolyfillLoaded = true;

            const extPrefix = "__quetta_ext_" + "$extensionId" + "_";

            window.chrome.runtime = {
                id: "$extensionId",
                getURL: function(path) {
                    return "https://quetta-extension.local/$extensionId/" + path.replace(/^\//, '');
                },
                sendMessage: function(message, callback) {
                    if (window.QuettaNativeBridge) {
                        const res = window.QuettaNativeBridge.onRuntimeMessage("$extensionId", JSON.stringify(message));
                        if (callback) callback(JSON.parse(res || "{}"));
                    }
                },
                onMessage: {
                    _listeners: [],
                    addListener: function(fn) { this._listeners.push(fn); }
                }
            };

            window.chrome.storage = {
                local: {
                    get: function(keys, callback) {
                        let result = {};
                        try {
                            if (typeof keys === "string") {
                                result[keys] = JSON.parse(localStorage.getItem(extPrefix + keys));
                            } else if (Array.isArray(keys)) {
                                keys.forEach(k => {
                                    result[k] = JSON.parse(localStorage.getItem(extPrefix + k));
                                });
                            } else if (typeof keys === "object" && keys !== null) {
                                Object.keys(keys).forEach(k => {
                                    const raw = localStorage.getItem(extPrefix + k);
                                    result[k] = raw !== null ? JSON.parse(raw) : keys[k];
                                });
                            }
                        } catch (e) {}
                        if (callback) callback(result);
                        return Promise.resolve(result);
                    },
                    set: function(items, callback) {
                        try {
                            Object.keys(items).forEach(k => {
                                localStorage.setItem(extPrefix + k, JSON.stringify(items[k]));
                            });
                        } catch (e) {}
                        if (callback) callback();
                        return Promise.resolve();
                    }
                },
                sync: null
            };
            window.chrome.storage.sync = window.chrome.storage.local;
            window.browser = window.chrome;
        })();
        """.trimIndent()
    }
}
